function searchMedia(){
  const q = document.getElementById("search").value.trim().toLowerCase();
  document.querySelectorAll(".card").forEach(card=>{
    const title=(card.dataset.title||"").toLowerCase();
    card.style.display = !q || title.includes(q) ? "" : "none";
  });
}
document.getElementById("search").addEventListener("keydown",e=>{if(e.key==="Enter")searchMedia()});